package test.wallethub.parser;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import javax.persistence.*;

/**
 *
 * @author yumarx.polanco
 */
public class App {

    /**
     * @param args the command line arguments
     */
    private static final String LOG_FILE = "../access.log";
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    public static void main(String[] args) {
        
        List<LogEntity> logList = null;
        try {
            logList = Files.lines(Paths.get(LOG_FILE))
                    .map(line -> line.split("\\|"))
                    .map(logs -> new LogEntity(LocalDateTime.parse(logs[0], formatter), logs[1], logs[2], logs[3], logs[4]))
                    .collect(Collectors.toList());
        } catch (IOException ex) {
            Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
        }
        


        EntityManagerFactory emf = Persistence.createEntityManagerFactory("test.wallethub_parser_PU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        try {
            for (LogEntity log : logList) {
                System.out.println(log.getDate());
                em.persist(log);
            }
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            em.getTransaction().rollback();
        } finally {
            em.close();
        }

    }

}
